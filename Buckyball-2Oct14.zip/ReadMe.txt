Product: Buckyball, October 2014

Designer: Chris Wundram

Support:  http://forums.obrary.com/category/designs/buckyball

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design
Description:
The Buckyball is a truncated icosohedron made from .1" acrylic sheet cut on a laser cutter.